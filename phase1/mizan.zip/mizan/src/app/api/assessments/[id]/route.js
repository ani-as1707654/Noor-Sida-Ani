import {
  getAssessments,
  updateAssessment,
  deleteAssessment,
} from "../../../../lib/utils";

export async function GET(req, { params }) {
  try {
    // Await the entire params object
    const resolvedParams = await params;
    const id = resolvedParams.id;

    const assessments = getAssessments();
    const assessment = assessments.find((a) => a.id === parseInt(id));

    if (!assessment) {
      return new Response(JSON.stringify({ error: "Assessment not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify(assessment), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}

export async function PUT(req, { params }) {
  try {
    // Await the entire params object
    const resolvedParams = await params;
    const id = resolvedParams.id;

    const body = await req.json();

    const assessment = updateAssessment(parseInt(id), body);

    return new Response(
      JSON.stringify({
        message: "Assessment updated successfully",
        assessment,
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }
}

export async function DELETE(req, { params }) {
  try {
    // Await the entire params object
    const resolvedParams = await params;
    const id = resolvedParams.id;

    deleteAssessment(parseInt(id));

    return new Response(
      JSON.stringify({ message: "Assessment deleted successfully" }),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }
}
