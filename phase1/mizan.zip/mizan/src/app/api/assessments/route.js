// File: src/app/api/assessments/route.js
import { getAssessments, addAssessment } from "../../../lib/utils";

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get("userId");
  const courseId = searchParams.get("courseId");
  const role = searchParams.get("role");

  const data = getAssessments(
    userId ? Number(userId) : null,
    courseId ? Number(courseId) : null,
    role
  );

  return new Response(JSON.stringify(data), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}

export async function POST(req) {
  try {
    const body = await req.json();
    const assessment = addAssessment(body);
    return new Response(
      JSON.stringify({ message: "Assessment added successfully", assessment }),
      {
        status: 201,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }
}
