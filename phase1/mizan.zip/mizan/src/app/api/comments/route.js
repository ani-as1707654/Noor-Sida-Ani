// File: src/app/api/comments/route.js
import { getComments, addComment } from "../../../lib/utils";

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const courseId = searchParams.get("courseId");

  const comments = getComments(courseId ? Number(courseId) : null);
  return new Response(JSON.stringify(comments), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}

export async function POST(req) {
  try {
    const body = await req.json();
    const comment = addComment(body);
    return new Response(
      JSON.stringify({ message: "Comment added successfully", comment }),
      {
        status: 201,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }
}
