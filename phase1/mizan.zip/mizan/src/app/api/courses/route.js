// File: src/app/api/courses/route.js
import { getCourses } from "@/lib/utils.js";

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get("userId");
  const programId = searchParams.get("programId");

  try {
    const courses = getCourses(userId ? Number(userId) : null, programId);

    return new Response(JSON.stringify(courses), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message || "Failed to fetch courses" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
}
