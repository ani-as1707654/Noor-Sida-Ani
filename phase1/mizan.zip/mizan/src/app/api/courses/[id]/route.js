// File: src/app/api/courses/[id]/route.js
import { getCourseById, updateCourse, deleteCourse } from "@/lib/utils.js";

export async function GET(req, { params }) {
  try {
    const course = getCourseById(Number(params.id));
    if (!course) {
      return new Response(JSON.stringify({ error: "Course not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }
    return new Response(JSON.stringify(course), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }
}

export async function PUT(req, { params }) {
  try {
    const body = await req.json();
    const course = updateCourse(Number(params.id), body);
    return new Response(
      JSON.stringify({ message: "Course updated successfully", course }),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: error.message.includes("not found") ? 404 : 400,
      headers: { "Content-Type": "application/json" },
    });
  }
}
