import LoginForm from "./components/LoginForm";

export default function HomePage() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}
