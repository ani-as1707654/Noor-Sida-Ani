"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { BookOpen, Clock, PenLine, Percent, AlertCircle } from "lucide-react";

export default function AssessmentForm({ assessmentId }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const id = assessmentId || searchParams.get("id");
  const isEditing = !!id;

  const [user, setUser] = useState(null);
  const [courses, setCourses] = useState([]);
  const [form, setForm] = useState({
    courseId: "",
    title: "",
    type: "Homework",
    dueDate: "",
    effortHours: "",
    weight: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);
      fetchCourses(parsedUser);
      if (isEditing) {
        fetchAssessment(id);
      }
    } else {
      router.push("/login");
    }
  }, [id, isEditing, router]);

  const fetchCourses = async (user) => {
    try {
      const url =
        user.role === "instructor"
          ? `/api/courses?userId=${user.id}`
          : "/api/courses";

      const res = await fetch(url);
      if (res.ok) {
        const coursesData = await res.json();
        setCourses(coursesData);
        if (coursesData.length > 0 && !isEditing) {
          setForm((prev) => ({ ...prev, courseId: coursesData[0].id }));
        }
      }
    } catch (error) {
      console.error("Error fetching courses:", error);
    }
  };

  const fetchAssessment = async (assessmentId) => {
    if (!assessmentId) return;

    setLoading(true);
    try {
      const res = await fetch(`/api/assessments/${assessmentId}`);
      if (res.ok) {
        const assessment = await res.json();
        const dueDate = new Date(assessment.dueDate);
        const formattedDate = dueDate.toISOString().slice(0, 16);

        setForm({
          courseId: assessment.courseId.toString(),
          title: assessment.title,
          type: assessment.type,
          dueDate: formattedDate,
          effortHours: assessment.effortHours.toString(),
          weight: assessment.weight.toString(),
        });
      } else {
        setError("Failed to fetch assessment");
      }
    } catch (error) {
      console.error("Error fetching assessment:", error);
      setError("Failed to load assessment data");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!user) {
      setError("You must be logged in");
      return;
    }

    const assessmentData = {
      ...form,
      courseId: parseInt(form.courseId),
      effortHours: parseFloat(form.effortHours),
      weight: parseFloat(form.weight),
      createdBy: user.id,
    };

    try {
      const url = isEditing ? `/api/assessments/${id}` : "/api/assessments";
      const method = isEditing ? "PUT" : "POST";

      const response = await fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(assessmentData),
      });

      const result = await response.json();

      if (response.ok) {
        router.push("/dashboard/assessments");
      } else {
        setError(
          result.error || `Failed to ${isEditing ? "update" : "add"} assessment`
        );
      }
    } catch (err) {
      setError("Something went wrong");
    }
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-center p-8">
          <div className="text-black">Loading assessment data...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md">
      <div className="p-6 border-b">
        <h1 className="text-2xl font-semibold text-black">
          {isEditing ? "Edit Assessment" : "Create New Assessment"}
        </h1>
        <p className="text-black mt-1">
          {isEditing
            ? "Update the assessment details below"
            : "Enter the details for the new assessment"}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="p-6">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="h-5 w-5 text-black" />
              <h3 className="text-lg font-medium text-black">
                Course Information
              </h3>
            </div>
            <div className="border-t pt-4">
              <label className="block text-sm font-medium text-black mb-1">
                Course
              </label>
              <select
                name="courseId"
                value={form.courseId}
                onChange={handleChange}
                disabled={isEditing}
                className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-black text-black bg-white"
                required
              >
                <option value="">Select a course</option>
                {courses.map((course) => (
                  <option key={course.id} value={course.id.toString()}>
                    {course.code}: {course.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <PenLine className="h-5 w-5 text-black" />
              <h3 className="text-lg font-medium text-black">
                Assessment Details
              </h3>
            </div>
            <div className="border-t pt-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-black mb-1">
                  Title
                </label>
                <input
                  type="text"
                  name="title"
                  value={form.title}
                  onChange={handleChange}
                  placeholder="Assignment title"
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-black text-black bg-white"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-black mb-1">
                  Type
                </label>
                <select
                  name="type"
                  value={form.type}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-black text-black bg-white"
                  required
                >
                  <option value="Homework">Homework</option>
                  <option value="Midterm exam">Midterm Exam</option>
                  <option value="Final exam">Final Exam</option>
                  <option value="Project">Project</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-black mb-1">
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4 text-black" />
                    Due Date & Time
                  </span>
                </label>
                <input
                  type="datetime-local"
                  name="dueDate"
                  value={form.dueDate}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-black text-black bg-white"
                  required
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <Percent className="h-5 w-5 text-black" />
              <h3 className="text-lg font-medium text-black">
                Grading Information
              </h3>
            </div>
            <div className="border-t pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-black mb-1">
                    Effort Hours
                  </label>
                  <input
                    type="number"
                    name="effortHours"
                    min="0"
                    step="0.5"
                    value={form.effortHours}
                    onChange={handleChange}
                    placeholder="e.g. 3.5"
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-black text-black bg-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-black mb-1">
                    Weight (%)
                  </label>
                  <input
                    type="number"
                    name="weight"
                    min="0"
                    max="100"
                    step="0.1"
                    value={form.weight}
                    onChange={handleChange}
                    placeholder="e.g. 15.5"
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-black text-black bg-white"
                    required
                  />
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-4 border border-red-200 bg-red-50 rounded-md text-black">
              <AlertCircle className="h-4 w-4 text-black" />
              <p>{error}</p>
            </div>
          )}
        </div>

        <div className="mt-6 pt-6 border-t flex justify-between">
          <button
            type="button"
            onClick={() => router.push("/dashboard/assessments")}
            className="px-4 py-2 border rounded-md hover:bg-gray-50 transition-colors text-black"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-black text-white rounded-md hover:bg-gray-800 transition-colors"
          >
            {isEditing ? "Update" : "Create"} Assessment
          </button>
        </div>
      </form>
    </div>
  );
}
