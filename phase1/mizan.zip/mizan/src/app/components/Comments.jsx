"use client";
import { useEffect, useState } from "react";

export default function Comments({ courseId }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState({ title: "", body: "" });
  const [user, setUser] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadComments = async () => {
    try {
      const res = await fetch(`/api/comments?courseId=${courseId}`);
      if (res.ok) {
        const data = await res.json();
        setComments(data);
      } else {
        console.error("Failed to fetch comments");
      }
    } catch (error) {
      console.error("Error loading comments:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewComment((prev) => ({ ...prev, [name]: value }));
  };

  const submitComment = async (e) => {
    e.preventDefault();
    if (!user) return;

    setIsSubmitting(true);
    try {
      const response = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          courseId,
          title: newComment.title,
          body: newComment.body,
          createdBy: user.id,
        }),
      });

      if (response.ok) {
        setNewComment({ title: "", body: "" });
        loadComments();
      } else {
        console.error("Failed to post comment");
      }
    } catch (error) {
      console.error("Error submitting comment:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    loadComments();
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, [courseId]);

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-sm p-6">
      <h4 className="text-2xl font-bold mb-6 text-gray-900 border-b pb-4">
        Course Discussion
      </h4>

      {comments.length > 0 ? (
        <ul className="space-y-6 mb-8">
          {comments.map((c) => (
            <li
              key={c.id}
              className="bg-gray-50 rounded-lg p-5 transition-all duration-200 hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <h5 className="text-lg font-semibold text-gray-900 mb-2">
                  {c.title}
                </h5>
                <span className="text-xs text-gray-500">
                  {new Date(c.createdAt).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </span>
              </div>
              <p className="text-gray-700 leading-relaxed mb-3 whitespace-pre-wrap">
                {c.body}
              </p>
              <div className="flex items-center text-sm text-gray-500">
                <span className="flex items-center">
                  <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                  Posted by {c.createdBy}
                </span>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="text-center py-8 bg-gray-50 rounded-lg mb-8">
          <p className="text-gray-600 font-medium">
            No comments yet. Start the discussion!
          </p>
        </div>
      )}

      {user ? (
        <form
          onSubmit={submitComment}
          className="bg-gray-50 p-6 rounded-lg border border-gray-100"
        >
          <div className="mb-4">
            <label
              htmlFor="title"
              className="block text-sm font-semibold text-gray-700 mb-2"
            >
              Title
            </label>
            <input
              id="title"
              name="title"
              type="text"
              value={newComment.title}
              onChange={handleChange}
              placeholder="What's on your mind?"
              required
              className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200 ease-in-out text-black"
            />
          </div>

          <div className="mb-4">
            <label
              htmlFor="body"
              className="block text-sm font-semibold text-gray-700 mb-2"
            >
              Your Message
            </label>
            <textarea
              id="body"
              name="body"
              value={newComment.body}
              onChange={handleChange}
              placeholder="Share your thoughts with the class..."
              required
              rows="4"
              className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200 ease-in-out resize-none text-black"
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`
                px-6 py-2.5 rounded-lg text-white font-medium
                ${
                  isSubmitting
                    ? "bg-blue-400 cursor-not-allowed"
                    : "bg-blue-600 hover:bg-blue-700 active:bg-blue-800"
                }
                transition duration-200 ease-in-out
                focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                transform hover:-translate-y-0.5
              `}
            >
              {isSubmitting ? (
                <span className="flex items-center">
                  <svg
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Posting...
                </span>
              ) : (
                "Post Comment"
              )}
            </button>
          </div>
        </form>
      ) : (
        <div className="bg-gray-50 border border-gray-200 p-8 rounded-lg text-center">
          <p className="text-gray-700 font-medium">
            Please log in to join the discussion
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Your insights make our community better
          </p>
        </div>
      )}
    </div>
  );
}
