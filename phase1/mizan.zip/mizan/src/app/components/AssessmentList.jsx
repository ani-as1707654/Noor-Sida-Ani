"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Calendar,
  Clock,
  Percent,
  Edit2,
  Trash2,
  MessageSquare,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import Comments from "./Comments";

export default function AssessmentList({ assessments, courses, user }) {
  const router = useRouter();
  const [expandedCourse, setExpandedCourse] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const assessmentsByCourse = assessments.reduce((acc, assessment) => {
    const courseId = assessment.courseId;
    if (!acc[courseId]) {
      acc[courseId] = [];
    }
    acc[courseId].push(assessment);
    return acc;
  }, {});

  const getCourseTitle = (courseId) => {
    const course = courses.find((c) => c.id === courseId);
    return course ? `${course.code}: ${course.title}` : "Unknown Course";
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const toggleComments = (courseId) => {
    setExpandedCourse(expandedCourse === courseId ? null : courseId);
  };

  const handleEdit = (assessmentId) => {
    router.push(`/dashboard/assessments/edit?id=${assessmentId}`);
  };

  const handleDelete = async (assessmentId) => {
    if (!confirm("Are you sure you want to delete this assessment?")) {
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await fetch(`/api/assessments/${assessmentId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        window.location.reload();
      } else {
        const data = await response.json();
        setError(data.error || "Failed to delete assessment");
      }
    } catch (err) {
      console.error("Error deleting assessment:", err);
      setError("Something went wrong while deleting the assessment");
    } finally {
      setLoading(false);
    }
  };

  const canModify =
    user && (user.role === "instructor" || user.role === "coordinator");

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {loading && (
        <div className="text-center py-4 text-gray-600">
          <div className="animate-spin h-6 w-6 border-2 border-blue-600 border-t-transparent rounded-full inline-block mr-2"></div>
          Processing...
        </div>
      )}

      {Object.keys(assessmentsByCourse).map((courseId) => {
        const numericCourseId = parseInt(courseId);
        return (
          <div
            key={courseId}
            className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
          >
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-gray-900">
                  {getCourseTitle(numericCourseId)}
                </h3>
                <button
                  onClick={() => toggleComments(numericCourseId)}
                  className="inline-flex items-center px-3 py-1.5 bg-white border border-gray-300 hover:bg-gray-50 text-sm font-medium rounded-md transition-colors"
                >
                  <MessageSquare className="h-4 w-4 mr-1.5" />
                  {expandedCourse === numericCourseId ? (
                    <span className="flex items-center text-black">
                      Hide Comments <ChevronUp className="ml-1 h-4 w-4" />
                    </span>
                  ) : (
                    <span className="flex items-center text-black">
                      Show Comments <ChevronDown className="ml-1 h-4 w-4" />
                    </span>
                  )}
                </button>
              </div>
            </div>

            <div className="divide-y divide-gray-200">
              {assessmentsByCourse[courseId].map((assessment) => (
                <div
                  key={assessment.id}
                  className="p-6 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4">
                    <div className="flex-1">
                      <h4 className="text-xl font-medium text-gray-900 mb-3">
                        {assessment.title}
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="flex items-center text-gray-600">
                          <Calendar className="h-5 w-5 mr-2 text-gray-400" />
                          <span>{formatDate(assessment.dueDate)}</span>
                        </div>

                        <div className="flex items-center text-gray-600">
                          <Clock className="h-5 w-5 mr-2 text-gray-400" />
                          <span>{assessment.effortHours} hours effort</span>
                        </div>

                        <div className="flex items-center text-gray-600">
                          <Percent className="h-5 w-5 mr-2 text-gray-400" />
                          <span>{assessment.weight}% of final grade</span>
                        </div>
                      </div>

                      <div className="mt-3">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {assessment.type}
                        </span>
                      </div>
                    </div>

                    {canModify && (
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEdit(assessment.id)}
                          className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Edit assessment"
                        >
                          <Edit2 className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => handleDelete(assessment.id)}
                          className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete assessment"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {expandedCourse === numericCourseId && (
              <div className="border-t border-gray-200 bg-gray-50 p-6">
                <Comments courseId={numericCourseId} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
