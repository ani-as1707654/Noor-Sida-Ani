// AddAssessmentPage.js
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AssessmentForm from "@/app/components/AssessmentForm";

export default function AddAssessmentPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Check if user is logged in and has permission
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      router.push("/login");
      return;
    }

    const parsedUser = JSON.parse(storedUser);

    // Only instructors and coordinators can add assessments
    if (parsedUser.role !== "instructor" && parsedUser.role !== "coordinator") {
      router.push("/dashboard/assessments");
      return;
    }

    setUser(parsedUser);
  }, []);

  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2>Add New Assessment</h2>
      <AssessmentForm />
    </div>
  );
}
