"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AssessmentList from "@/app/components/AssessmentList";
import { PlusCircle, BookOpen, Loader2 } from "lucide-react";

export default function AssessmentPage() {
  const router = useRouter();
  const [assessments, setAssessments] = useState([]);
  const [courses, setCourses] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      router.push("/login");
      return;
    }

    const parsedUser = JSON.parse(storedUser);
    setUser(parsedUser);

    Promise.all([fetchAssessments(parsedUser), fetchCourses(parsedUser)])
      .then(() => setLoading(false))
      .catch((err) => {
        console.error("Error loading data:", err);
        setError("Failed to load data");
        setLoading(false);
      });
  }, []);

  const fetchAssessments = async (user) => {
    try {
      const url = `/api/assessments?userId=${user.id}&role=${user.role}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setAssessments(data);
      } else {
        throw new Error("Failed to fetch assessments");
      }
    } catch (error) {
      console.error("Error fetching assessments:", error);
      throw error;
    }
  };

  const fetchCourses = async (user) => {
    try {
      const url =
        user.role === "coordinator"
          ? "/api/courses"
          : `/api/courses?userId=${user.id}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setCourses(data);
      } else {
        console.error("Failed to fetch courses:", await res.text());
        setCourses([]);
      }
    } catch (error) {
      console.error("Error fetching courses:", error);
      setCourses([]);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex items-center space-x-2 text-gray-600">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading assessments...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-red-50 text-red-700 p-4 rounded-lg max-w-md text-center">
          <p className="font-medium">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-2 text-sm text-red-600 hover:text-red-500"
          >
            Try again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <BookOpen className="h-8 w-8 text-blue-600" />
            Assessments
          </h1>
          <p className="mt-2 text-gray-600">
            Manage and view course assessments
          </p>
        </div>

        {(user?.role === "instructor" || user?.role === "coordinator") && (
          <a
            href="/dashboard/assessments/add"
            className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
          >
            <PlusCircle className="h-5 w-5 mr-2" />
            Add New Assessment
          </a>
        )}
      </div>

      {assessments.length > 0 ? (
        <AssessmentList
          assessments={assessments}
          courses={courses}
          user={user}
        />
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <BookOpen className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-4 text-lg font-medium text-gray-900">
            No assessments found
          </h3>
          <p className="mt-2 text-gray-600">
            No assessments have been added yet.
          </p>
        </div>
      )}
    </div>
  );
}
