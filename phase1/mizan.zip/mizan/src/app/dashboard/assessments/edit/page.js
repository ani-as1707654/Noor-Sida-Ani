"use client";

import AssessmentForm from "@/app/components/AssessmentForm";

export default function EditAssessmentPage() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Edit Assessment</h1>
      <AssessmentForm />
    </div>
  );
}
