module.exports = {

"[project]/.next-internal/server/app/api/login/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/path [external] (path, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}}),
"[project]/src/lib/utils.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "addAssessment": (()=>addAssessment),
    "addComment": (()=>addComment),
    "deleteAssessment": (()=>deleteAssessment),
    "getAssessments": (()=>getAssessments),
    "getComments": (()=>getComments),
    "getUsers": (()=>getUsers),
    "updateAssessment": (()=>updateAssessment),
    "validateUser": (()=>validateUser)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
// File paths
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), "data");
const USERS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(DATA_DIR, "users.json");
const COURSES_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(DATA_DIR, "courses.json");
const ASSESSMENTS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(DATA_DIR, "assessments.json");
const COMMENTS_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(DATA_DIR, "comments.json");
// Helper functions for file operations
const ensureDataDirExists = ()=>{
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(DATA_DIR)) {
        __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].mkdirSync(DATA_DIR, {
            recursive: true
        });
    }
};
const readDataFile = (filePath, defaultData)=>{
    try {
        if (__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(filePath)) {
            const data = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readFileSync(filePath, "utf8");
            return JSON.parse(data);
        }
        return defaultData;
    } catch (error) {
        console.error(`Error reading file ${filePath}:`, error);
        return defaultData;
    }
};
const writeDataFile = (filePath, data)=>{
    try {
        ensureDataDirExists();
        __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].writeFileSync(filePath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error(`Error writing file ${filePath}:`, error);
        return false;
    }
};
const getUsers = ()=>{
    return readDataFile(USERS_FILE, {
        users: []
    }).users;
};
const validateUser = (username, password)=>{
    const users = getUsers();
    // Add a safety check before using .find()
    if (!Array.isArray(users)) {
        console.error("Expected users to be an array, got:", users);
        return null;
    }
    return users.find((user)=>user.username === username && user.password === password) || null;
};
const getAssessments = (userId = null, courseId = null, role = null)=>{
    const assessments = readDataFile(ASSESSMENTS_FILE, {
        assessments: []
    }).assessments;
    const users = getUsers();
    const courses = readDataFile(COURSES_FILE, {
        courses: []
    }).courses;
    if (!userId) return assessments;
    const user = users.find((u)=>u.id === userId);
    if (!user) return [];
    // Filter assessments based on user role and permissions
    if (user.role === "instructor") {
        // Instructors can see assessments for courses they teach
        const instructorCourseIds = courses.filter((course)=>course.instructorId === userId).map((course)=>course.id);
        return assessments.filter((assessment)=>instructorCourseIds.includes(assessment.courseId) && (!courseId || assessment.courseId === courseId));
    } else if (user.role === "coordinator") {
        // Coordinators can access any assessment or filter by program
        if (courseId) {
            return assessments.filter((assessment)=>assessment.courseId === courseId);
        }
        // If program filter is needed, implement it here
        return assessments;
    } else if (user.role === "student") {
        // Students can only see assessments for their courses
        return assessments.filter((assessment)=>user.courses.includes(assessment.courseId) && (!courseId || assessment.courseId === courseId));
    }
    return [];
};
const addAssessment = (assessmentData)=>{
    const { courseId, title, type, dueDate, effortHours, weight, createdBy } = assessmentData;
    // Load existing assessments
    const data = readDataFile(ASSESSMENTS_FILE, {
        assessments: []
    });
    const courseAssessments = data.assessments.filter((a)=>a.courseId === courseId);
    // Validate assessment data
    const finalExams = courseAssessments.filter((a)=>a.type === "Final exam");
    const midterms = courseAssessments.filter((a)=>a.type === "Midterm exam");
    const homeworks = courseAssessments.filter((a)=>a.type === "Homework");
    const projects = courseAssessments.filter((a)=>a.type === "Project");
    // Check validation rules
    if (type === "Final exam" && finalExams.length >= 1) {
        throw new Error("Only one final exam can be added per course");
    }
    if (type === "Midterm exam" && midterms.length >= 2) {
        throw new Error("At most 2 midterm exams can be added per course");
    }
    if (type === "Homework" && homeworks.length >= 8) {
        throw new Error("Maximum 8 homework assignments per course");
    }
    // Check for duplicate due dates
    if (courseAssessments.some((a)=>new Date(a.dueDate).toDateString() === new Date(dueDate).toDateString())) {
        throw new Error("No two assessments for a course can have the same due date");
    }
    // Generate a new ID
    const newId = data.assessments.length > 0 ? Math.max(...data.assessments.map((a)=>a.id)) + 1 : 1;
    // Auto-generate title if not provided
    let finalTitle = title;
    if (!finalTitle) {
        // Count existing assessments of this type
        const typeCount = courseAssessments.filter((a)=>a.type === type).length + 1;
        finalTitle = typeCount > 1 ? `${type} ${typeCount}` : type;
    }
    // Create the new assessment
    const newAssessment = {
        id: newId,
        courseId,
        title: finalTitle,
        type,
        dueDate,
        effortHours: Number(effortHours),
        weight: Number(weight),
        createdBy,
        createdAt: new Date().toISOString()
    };
    // Add and save
    data.assessments.push(newAssessment);
    writeDataFile(ASSESSMENTS_FILE, data);
    return newAssessment;
};
const updateAssessment = (id, assessmentData)=>{
    const data = readDataFile(ASSESSMENTS_FILE, {
        assessments: []
    });
    const index = data.assessments.findIndex((a)=>a.id === id);
    if (index === -1) {
        throw new Error("Assessment not found");
    }
    // Keep the original ID and createdAt
    const originalId = data.assessments[index].id;
    const originalCreatedAt = data.assessments[index].createdAt;
    // Update assessment with new data
    data.assessments[index] = {
        ...assessmentData,
        id: originalId,
        createdAt: originalCreatedAt,
        updatedAt: new Date().toISOString()
    };
    writeDataFile(ASSESSMENTS_FILE, data);
    return data.assessments[index];
};
const deleteAssessment = (id)=>{
    const data = readDataFile(ASSESSMENTS_FILE, {
        assessments: []
    });
    const index = data.assessments.findIndex((a)=>a.id === id);
    if (index === -1) {
        throw new Error("Assessment not found");
    }
    data.assessments.splice(index, 1);
    writeDataFile(ASSESSMENTS_FILE, data);
    return true;
};
const getComments = (courseId = null)=>{
    const comments = readDataFile(COMMENTS_FILE, {
        comments: []
    }).comments;
    if (courseId) {
        return comments.filter((comment)=>comment.courseId === courseId);
    }
    return comments;
};
const addComment = (commentData)=>{
    const { courseId, title, body, createdBy } = commentData;
    // Load existing comments
    const data = readDataFile(COMMENTS_FILE, {
        comments: []
    });
    // Generate a new ID
    const newId = data.comments.length > 0 ? Math.max(...data.comments.map((c)=>c.id)) + 1 : 1;
    // Create the new comment
    const newComment = {
        id: newId,
        courseId,
        title,
        body,
        createdBy,
        createdAt: new Date().toISOString()
    };
    // Add and save
    data.comments.push(newComment);
    writeDataFile(COMMENTS_FILE, data);
    return newComment;
};
}}),
"[project]/src/app/api/login/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-route] (ecmascript)");
;
async function POST(req) {
    const { username, password } = await req.json();
    const user = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["validateUser"])(username, password);
    if (!user) {
        return new Response("Invalid credentials", {
            status: 401
        });
    }
    // Simulate session token generation (for simplicity)
    return new Response(JSON.stringify({
        message: "Login successful",
        user
    }), {
        status: 200
    });
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__c5f161ba._.js.map